package I;

import java.lang.*;
public class Main {
    public static void main(String[] args) {
        Ball b1 = new Ball("Basketball", "Brown");
        Ball b2 = new Ball("Voleyball", " White");
        b1.Print();
        b2.Print();
    }
}

