package IV;

public class Main {
    public static void main(String[] args) {
        new NullLayout().setVisible(true);
    }
}
