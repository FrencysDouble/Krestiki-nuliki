package IV;

public interface Priceable {
    double getPrice();
}
