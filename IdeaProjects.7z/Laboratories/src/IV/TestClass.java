package IV;


public class TestClass {
    public static void main(String[] args) {
        Book b1 = new Book(340, "Harry Potter", 1);
        System.out.println(b1.toString());
    }
}
